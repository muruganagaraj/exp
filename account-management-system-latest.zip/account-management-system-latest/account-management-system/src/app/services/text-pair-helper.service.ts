import { Injectable } from '@angular/core';

@Injectable()
export class TextPairHelperService {
    public getTextPairValue(pairs: TextPair[], text: string): string {
        if (!pairs || pairs.length === 0 || !text) {
            return undefined;
        }
        for (let i: number = 0; i < pairs.length; i++) {
            if (pairs[i].text === text) {
                return pairs[i].value;
            }
        }
        return undefined;
    }
    public getTextPairText(pairs: TextPair[], value: string): string {
        if (!pairs || pairs.length === 0 || !value) {
            return undefined;
        }
        for (let i: number = 0; i < pairs.length; i++) {
            if (pairs[i].value === value) {
                return pairs[i].text;
            }
        }
        return undefined;
    }


    public createGSTTextPair(data: any[]): TextPair[] {
        let firstTime: boolean = false;
        return (data || []).reduce((filter: TextPair[], item: any) => {
            const name: string = item.GSTCode;
            const code: string = item.GST;
            if (!filter.some((pair: TextPair) => pair.value === code) ||
                !filter.some((pair: TextPair) => pair.text === name)) {
                if (!firstTime) {
                    filter.push(<TextPair>{
                        text: 'Select',
                        value: undefined
                    });
                    firstTime = true;
                }
                filter.push(<TextPair>{
                    text: item.GSTCode,
                    value: item.GST
                });
            }
            return filter;
        }, []);
    }
    public createBuyerTextPair(data: any[]): TextPair[] {
        let firstTime: boolean = false;
        return (data || []).reduce((filter: TextPair[], item: any) => {
            const name: string = item.Name;
            const code: string = item.BuyerId;
            if (!filter.some((pair: TextPair) => pair.value === code) ||
                !filter.some((pair: TextPair) => pair.text === name)) {
                if (!firstTime) {
                    filter.push(<TextPair>{
                        text: 'Select',
                        value: undefined
                    });
                    firstTime = true;
                }
                filter.push(<TextPair>{
                    text: item.Name,
                    value: item.BuyerId
                });
            }
            return filter;
        }, []);
    }
}
