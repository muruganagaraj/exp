import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AddExpenseDetailComponent } from 'app/add-expense-detail/add-expense-detail.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ExpenseDetail } from 'model/expenseModel';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { TextPairHelperService } from '../services/text-pair-helper.service';

@Component({
  selector: 'app-expense-detail',
  templateUrl: './expense-detail.component.html',
  styleUrls: ['./expense-detail.component.scss']
})
export class ExpenseDetailComponent implements OnInit {
  expenseForm: FormGroup;
  isGSTRequired: boolean;
  buyerList: TextPair[] = [];
  isExpensive: boolean = false;
  constructor(public dialog: MatDialog, private formBuilder: FormBuilder,
    private http: HttpClient,
    private textPairHelperService: TextPairHelperService) { }
  ngOnInit() {
    this.isGSTRequired = false;
    this.getBuyerList();
  }
  getBuyerList(): any {
    const endpoint: string = 'https://cfztsaiwb1.execute-api.us-east-1.amazonaws.com/default/EDU_B_GETAll';
    this.http.get(endpoint).subscribe((item: any) => {
      this.buyerList = this.textPairHelperService.createBuyerTextPair(item);
    });
  }

  openDialog(): void {
    debugger;
    const dialogRef = this.dialog.open(AddExpenseDetailComponent, {
      height: "auto",
      width: "auto",
      data: { undefined }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  onChange(value: any): void {
    alert(value);
  }

  onSubmit() {

  }
}
