export interface viewmodel {
    GSTId?: number;
    GSTCode?: string;
    GST?: number;
    Description?: string;
}